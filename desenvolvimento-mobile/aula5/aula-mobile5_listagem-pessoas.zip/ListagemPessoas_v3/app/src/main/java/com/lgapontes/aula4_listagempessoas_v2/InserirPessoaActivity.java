package com.lgapontes.aula4_listagempessoas_v2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class InserirPessoaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inserir_pessoa);
    }
}
